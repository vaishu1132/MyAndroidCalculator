package com.example.mycalculator;

public class Calculate {
    public String add(double val1, double val2){
        return String.valueOf(val1+val2);
    }

    public String sub(double val1, double val2){
        return String.valueOf(val1-val2);
    }

    public String mul(double val1, double val2){
        return String.valueOf(val1 * val2);
    }

    public String div(double val1, double val2){
        return String.valueOf(val1/val2);
    }

    public String tan(double num){
        return String.valueOf(Math.tan(Math.toRadians(num)));
    }

    public String cos(double num){
        return String.valueOf(Math.cos(Math.toRadians(num)));
    }

    public String sine(double num){
        return String.valueOf(Math.sin(Math.toRadians(num)));
    }

}

/*
Vaishali Krishnamurthy
Calculator app with basic arithmetic operations.
Note : Tan,Cosine and Sine operations are supported
input example : <num> TAN = <answer>
                <num> SIN = <answer>
                <num> COSINE = <answer>
5 TAN = 0.08748866352592401
 */
package com.example.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button bt_clear, bt_decimal, bt_equal, bt_add, bt_sub, bt_mul, bt_div, bt_tan, bt_cos, bt_sin,
    bt_0, bt_1, bt_2, bt_3, bt_4, bt_5, bt_6, bt_7, bt_8, bt_9;
    Double val1 = 0.0;
    Double val2 = 0.0;
    Double res = 0.0;
    boolean isAdd, isSub, isMul, isDiv, isTan, isSin, isCos;
    EditText et_answer;
    //Class handling arithmetic operations
    Calculate calc = new Calculate();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_0 = findViewById(R.id.bt_0);
        bt_1 = findViewById(R.id.bt_1);
        bt_2 = findViewById(R.id.bt_2);
        bt_3 = findViewById(R.id.bt_3);
        bt_4 = findViewById(R.id.bt_4);
        bt_5 = findViewById(R.id.bt_5);
        bt_6 = findViewById(R.id.bt_6);
        bt_7 = findViewById(R.id.bt_7);
        bt_8 = findViewById(R.id.bt_8);
        bt_9 = findViewById(R.id.bt_9);
        bt_add = findViewById(R.id.bt_add);
        bt_sub = findViewById(R.id.bt_sub);
        bt_mul = findViewById(R.id.bt_mul);
        bt_div = findViewById(R.id.bt_div);
        bt_tan = findViewById(R.id.bt_tan);
        bt_cos = findViewById(R.id.bt_cos);
        bt_sin = findViewById(R.id.bt_sin);
        bt_equal = findViewById(R.id.bt_equal);
        bt_clear = findViewById(R.id.bt_clear);
        bt_decimal = findViewById(R.id.bt_decimal);
        et_answer = findViewById(R.id.pt_answer);

        bt_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"0");
            }
        });

        bt_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"1");
            }
        });

        bt_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"2");
            }
        });

        bt_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"3");
            }
        });

        bt_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"4");
            }
        });

        bt_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"5");
            }
        });

        bt_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"6");
            }
        });

        bt_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"7");
            }
        });

        bt_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"8");
            }
        });

        bt_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+"9");
            }
        });

        bt_decimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText(et_answer.getText()+".");
            }
        });

        bt_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et_answer.getText().toString().equals("")){
                    et_answer.setText("");
                }
                else{
                    isAdd = true;
                    if (val1!=0.0 && res == 0.0) {
                        val1 += Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                    else{
                        val1 = Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                }
            }
        });

        bt_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et_answer.getText().toString().equals("")){
                    et_answer.setText("-");
                }
                else {
                    isSub = true;
                    if (val1 != 0.0 && res == 0.0) {
                        val1 = val1 - Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                    else {
                        val1 = Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                }

            }
        });

        bt_mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et_answer.getText().toString().equals("")){
                    et_answer.setText("");
                }
                else{
                    isMul = true;
                    if(val1 != 0 && res ==0.0) {
                        val1 = val1 * Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                    else {
                        val1 = Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                }
            }
        });

        bt_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et_answer.getText().toString().equals("")){
                    et_answer.setText("");
                }
                else {
                    isDiv = true;
                    if (val1 != 0.0 && res == 0.0) {
                        val1 = val1 / Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                    else {
                        val1 = Double.parseDouble(et_answer.getText() + "");
                        et_answer.setText(null);
                    }
                }
            }
        });

        bt_tan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_answer.getText().toString().equals("")){
                    et_answer.setText("");
                }
                else {
                    isTan = true;
                    val1 = Double.parseDouble(et_answer.getText() + "");
                    et_answer.setText(null);
                }
            }
        });

        bt_cos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_answer.getText().toString().equals("")){
                    et_answer.setText("");
                }
                else {
                    isCos = true;
                    val1 = Double.parseDouble(et_answer.getText() + "");
                    et_answer.setText(null);
                }
            }
        });

        bt_sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_answer.getText().toString().equals("")){
                    et_answer.setText("");
                }
                else {
                    isSin = true;
                    val1 = Double.parseDouble(et_answer.getText() + "");
                    et_answer.setText(null);
                }
            }
        });



        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_answer.setText("");
                val1 = 0.0;
                val2 = 0.0;

            }
        });

        bt_equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val2 = 0.0;
                if(!et_answer.getText().toString().equals("")) {
                    val2 = Double.parseDouble(et_answer.getText() + "");
                }

                if(isAdd == true){
                    if(val2 == 0.0){
                        et_answer.setText(val1+"");
                    }
                    else {
                        et_answer.setText(calc.add(val1,val2));
                    }
                    isAdd = false;
                    res = Double.parseDouble(et_answer.getText() + "");

                }

                if(isSub == true){
                    if(val2 == 0.0) {
                        et_answer.setText(val1+"");
                    }
                    else {
                        et_answer.setText(calc.sub(val1,val2));
                    }
                    isSub = false;
                    res = Double.parseDouble(et_answer.getText() + "");

                }

                if(isMul == true){


                    et_answer.setText(calc.mul(val1,val2));

                    isMul = false;
                    res = Double.parseDouble(et_answer.getText() + "");

                }

                if(isDiv == true){


                    et_answer.setText(calc.div(val1,val2));
                    isDiv = false;
                    res = Double.parseDouble(et_answer.getText() + "");

                }

                if(isTan == true) {
                    et_answer.setText(calc.tan(val1));
                    isTan = false;
                }

                if(isCos == true) {
                    et_answer.setText(calc.cos(val1));
                    isCos = false;
                }

                if(isSin == true) {
                    et_answer.setText(calc.sine(val1));
                    isSin = false;
                }

            }
        });

    }


}